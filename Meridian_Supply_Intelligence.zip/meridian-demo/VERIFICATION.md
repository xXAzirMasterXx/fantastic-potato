# Delivery verification

## Automated checks

Run with `node --test tests/engine.test.cjs` using Node.js's built-in test runner. No test dependencies are required.

- Nine stages are visited in order; final delivery completes all nine milestones.
- The central ETA changes from 25 to 28 to 31 October.
- The three key states are On Track, Watch, and At Risk.
- The red alert predicts two days of delay and appears five days before the requested arrival.
- Every interval contains its central ETA, and interval width does not increase across the scenario.
- Every contribution breakdown reconciles to the displayed ETA.
- Remaining lead time agrees with the simulated date and ETA.
- Risk-boundary cases and uncertainty-triggered Watch status behave as documented.
- All five planner previews calculate expected dates without mutating the original ETA.
- Date formatting correctly crosses the October/November boundary.
- The standalone HTML has inline scripts/styles, no external asset references, and no unresolved build tokens.

The app and scenario JavaScript also pass Node's syntax checks.

## Browser checks

Inspected in Chromium, including a desktop viewport and embedded narrow viewports approximately 390 and 768 CSS pixels wide (375 and 753 pixels of content width with scrollbars).

- Healthy, QI-hold, and red-risk shortcut states.
- The timer advances from Watch to risk detection and pauses automatically at the alert.
- Dynamic chart, interval, status, current stage, live features, and event history refresh together.
- The Why? dialog displays the +5-day QI contribution, +2-day holiday contribution, +7-day total, and 31 October forecast.
- The expedited-freight comparison preserves the original ETA and shows the separate fulfilment estimate.
- All five action controls and their previews.
- All nine milestones complete when the scenario reaches final arrival; reset returns to the healthy state.
- Source inspection, milestone-history table, and page navigation.
- Light and dark appearance, executive brief, and mobile navigation.
- No full-page horizontal overflow in narrow layouts; the milestone row and record table can scroll within their cards.
- The long `30 Oct–1 Nov` interval fits the phone KPI card.

The print control uses the browser's native print dialog and dedicated print CSS; a PDF export is not included. Other browser engines were not exercised in this environment.
