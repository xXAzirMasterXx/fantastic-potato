/* Meridian's deterministic, illustrative scenario. No model or network calls. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MeridianEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const DAY = 86400000;
  const date = day => new Date(Date.UTC(2026, 9, day));
  const format = (day, options) => date(day).toLocaleDateString('en-GB', options || { day: 'numeric', month: 'short', timeZone: 'UTC' });
  const stages = [
    { name: 'Manufacturing', icon: 'factory', location: 'Basel, Switzerland', typical: 3, description: 'Medicine is produced and the batch record is created.' },
    { name: 'Release', icon: 'shield', location: 'Basel, Switzerland', typical: 2, description: 'The batch is reviewed and released for distribution.' },
    { name: 'Warehouse', icon: 'warehouse', location: 'European distribution centre', typical: 2, description: 'Released stock is picked and prepared for outbound delivery.' },
    { name: 'Export', icon: 'document', location: 'European distribution centre', typical: 1, description: 'Export documentation and customs declarations are completed.' },
    { name: 'Port', icon: 'anchor', location: 'Rotterdam, Netherlands', typical: 2, description: 'The container is received at port and loaded for departure.' },
    { name: 'Sea Freight', icon: 'ship', location: 'Europe → Singapore', typical: 8, description: 'The medicine travels by sea to the regional Singapore hub.' },
    { name: 'Import', icon: 'globe', location: 'Singapore regional hub', typical: 1, description: 'Inbound documentation and import clearance are completed.' },
    { name: 'QI Bulk', icon: 'flask', location: 'Singapore regional hub', typical: 2, description: 'Bulk stock awaits quality inspection and release for onward distribution.' },
    { name: 'Market Arrival', icon: 'pin', location: 'Manila, Philippines', typical: 1, description: 'The shipment reaches the receiving market and delivery is confirmed.' }
  ];
  const snapshots = [
    { day: 2, stage: 0, completed: 0, duration: 2, eta: 25, low: 20, high: 28, title: 'A healthy start', message: 'Production is progressing normally. The first ETA leaves four days of headroom.', event: 'Batch record received from ECC.', drivers: [1, 0] },
    { day: 4, stage: 1, completed: 1, duration: 1, eta: 25, low: 21, high: 28, title: 'Released for distribution', message: 'The batch is released. New evidence narrows the arrival window.', event: 'Batch release confirmed.', drivers: [1, 0] },
    { day: 6, stage: 2, completed: 2, duration: 1, eta: 25, low: 21, high: 28, title: 'Ready at the warehouse', message: 'Delivery documents connect the released batch to its outbound shipment.', event: 'Outbound delivery linked to batch.', drivers: [1, 0] },
    { day: 8, stage: 3, completed: 3, duration: 1, eta: 25, low: 22, high: 28, title: 'Export cleared', message: 'Export documentation is complete. Arrival remains ahead of the market request.', event: 'Export clearance posted.', drivers: [1, 0] },
    { day: 9, stage: 4, completed: 4, duration: 1, eta: 25, low: 22, high: 28, title: 'At the port', message: 'The container is checked in at Rotterdam and ready for the planned sailing.', event: 'Port gate-in confirmed.', drivers: [1, 0] },
    { day: 11, stage: 5, completed: 5, duration: 2, eta: 25, low: 23, high: 27, title: 'On the water', message: 'The shipment is moving toward Asia. Fewer unobserved stages reduce uncertainty.', event: 'Vessel departure received.', drivers: [1, 0] },
    { day: 20, stage: 6, completed: 6, duration: 1, eta: 25, low: 23, high: 27, title: 'Asia gateway reached', message: 'Import clearance is underway at the Singapore hub. The ETA remains 25 October.', event: 'Import arrival registered.', drivers: [1, 0] },
    { day: 21, stage: 7, completed: 7, duration: 1, eta: 25, low: 24, high: 26, title: 'Quality inspection begins', message: 'QI Bulk is within its typical two-day duration. No exception is predicted.', event: 'QI Bulk entry recorded.', drivers: [1, 0] },
    { day: 23, stage: 7, completed: 7, duration: 3, eta: 28, low: 27, high: 29, title: 'A signal worth watching', message: 'QI Bulk has exceeded its typical duration. The ETA moves from 25 to 28 October.', event: 'QI dwell threshold exceeded; ETA recalculated.', drivers: [3, 1] },
    { day: 24, stage: 7, completed: 7, duration: 4, eta: 31, low: 30, high: 32, title: 'Risk, before the missed date', message: 'The projected QI hold and a market holiday move the ETA to 31 October—two days after the request.', event: 'Projected QI overrun and market calendar trigger a risk alert.', drivers: [5, 2] },
    { day: 30, stage: 8, completed: 8, duration: 1, eta: 31, low: 31, high: 31, title: 'Released for the market', message: 'Quality release is confirmed. The next-day arrival estimate now has a narrow window.', event: 'QI release (27 Oct) linked; onward dispatch confirmed.', drivers: [5, 2] },
    { day: 31, stage: 8, completed: 9, duration: 0, eta: 31, low: 31, high: 31, title: 'The outcome is confirmed', message: 'The unmitigated shipment arrives two days late. The model had flagged this risk on 24 October.', event: 'Proof of delivery received in Manila.', drivers: [5, 2] }
  ].map((s, i) => Object.freeze({ ...s, index: i, expected: stages[s.stage].typical, remaining: Math.max(0, s.eta - s.day) }));
  const actions = [
    { id: 'expedite', name: 'Expedite freight', icon: 'plane', recover: 3, effort: 'Higher cost', description: 'Reserve priority onward uplift from the regional hub.', detail: 'Assumes an earlier carrier slot and priority handling are available after quality release.' },
    { id: 'inventory', name: 'Reallocate inventory', icon: 'boxes', recover: 2, effort: 'Stock dependent', description: 'Serve market demand from qualified regional stock.', detail: 'Estimates demand fulfilment using alternate stock; the original shipment ETA does not change.' },
    { id: 'production', name: 'Prioritize production', icon: 'factory', recover: 1, effort: 'Capacity dependent', description: 'Prioritize a replacement batch on an alternate route.', detail: 'Assumes a suitable replacement batch and a faster route can meet the market need.' },
    { id: 'engage', name: 'Engage market stakeholders', icon: 'users', recover: 0, effort: 'Align demand', description: 'Agree allocations and a revised receiving plan.', detail: 'Improves coordination and expectation setting; no transit-time recovery is assumed.' },
    { id: 'monitor', name: 'Monitor only', icon: 'eye', recover: 0, effort: 'No added cost', description: 'Keep the current route and review the next event.', detail: 'Retains the current prediction and accepts the illustrated delivery risk.' }
  ];
  function risk(eta, high = eta, requested = 29) {
    if (eta > requested) return { key: 'red', label: 'At Risk', delay: eta - requested, headroom: requested - eta };
    if (eta >= requested - 1 || high >= requested) return { key: 'amber', label: 'Watch', delay: 0, headroom: requested - eta };
    return { key: 'green', label: 'On Track', delay: 0, headroom: requested - eta };
  }
  function preview(snapshot, actionId) {
    const action = actions.find(a => a.id === actionId);
    if (!action) return null;
    const eta = Math.max(snapshot.day, snapshot.eta - action.recover);
    return { action, eta, recovered: snapshot.eta - eta, risk: risk(eta, eta) };
  }
  return Object.freeze({ DAY, date, format, stages, snapshots, actions, risk, preview, requested: 29, normalReference: 24, alertIndex: 9 });
});
