(function () {
  'use strict';
  const E = window.MeridianEngine;
  const $ = id => document.getElementById(id);
  const paths = {
    dashboard: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="11" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="18" width="7" height="3" rx="1"/>',
    database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v7c0 4 16 4 16 0V5M4 12v7c0 4 16 4 16 0v-7"/>',
    chart: '<path d="M4 3v17h17M8 15l4-5 4 2 5-7"/>',
    arrow: '<path d="M4 12h15M14 6l6 6-6 6"/>',
    chevron: '<path d="m9 5 7 7-7 7"/>',
    moon: '<path d="M20.4 15.5A9 9 0 0 1 8.5 3.6a9 9 0 1 0 11.9 11.9Z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    play: '<path d="m8 4 12 8-12 8Z"/>',
    pause: '<path d="M8 5v14M16 5v14" stroke-width="3"/>',
    reset: '<path d="M3 10a9 9 0 1 1 1.8 7M3 4v6h6"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 11h18m-12 4h1m4 0h1"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    shield: '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/><path d="m8 12 3 3 5-6"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    factory: '<path d="M3 21V10l6 4V8l6 4V3h5v18ZM7 17h1m4 0h1m4 0h1"/>',
    warehouse: '<path d="m3 9 9-6 9 6v12H3Z"/><path d="M7 21V11h10v10M7 15h10m-10 3h10"/>',
    document: '<path d="M14 3H5v18h14V8ZM14 3v5h5M8 12h8m-8 4h6"/>',
    anchor: '<path d="M12 7v14M5 11H2c0 7 6 10 10 10s10-3 10-10h-3M7 10h10"/><circle cx="12" cy="4" r="3"/>',
    ship: '<path d="m3 13 9-3 9 3-3 6H6ZM6 12V6h12v6M9 6V3h6v3M2 21q2-2 5 0 2-2 5 0 2-2 5 0 3-2 5 0"/>',
    globe: '<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18M5 6h14M5 18h14"/>',
    flask: '<path d="M9 3h6m-5 0v6L4 19q-1 2 2 2h12q3 0 2-2L14 9V3M7 14h10m-7 3h1m3 1h1"/>',
    pin: '<path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.5"/>',
    sparkles: '<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5ZM20 2v4m-2-2h4"/>',
    activity: '<path d="M2 12h5l3-8 4 16 3-8h5"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
    alert: '<path d="m12 3 10 18H2ZM12 9v5m0 3h.01"/>',
    plane: '<path d="m2 14 8-3 1-8 2-1 2 9 7 3v2l-8-1v5l3 2H7l3-2v-5l-8 1Z"/>',
    boxes: '<path d="m3 12 5-3 5 3v7l-5 3-5-3Zm10 0 5-3 5 3v7l-5 3-5-3ZM8 2l5 3v7L8 9 3 12V5Zm0 0L3 5m5 17v-7m10 7v-7"/>',
    users: '<circle cx="9" cy="7" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 4a3 3 0 0 1 0 6m2 5a5 5 0 0 1 3 4v2"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
    close: '<path d="m6 6 12 12M6 18 18 6"/>',
    link: '<path d="m10 13 4-4M8 15l-2 2a3.5 3.5 0 0 1-5-5l5-5a3.5 3.5 0 0 1 5 0m2 2 2-2a3.5 3.5 0 0 1 5 5l-5 5a3.5 3.5 0 0 1-5 0" transform="translate(1 0)"/>',
    batch: '<path d="m12 3 9 5-9 5-9-5ZM3 8v9l9 5 9-5V8M12 13v9M7 6l9 5"/>'
  };
  const icon = name => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.activity}</svg>`;
  document.querySelectorAll('[data-icon]').forEach(el => { el.innerHTML = icon(el.dataset.icon); });
  const state = { index: 0, playing: false, page: 'overview', inspected: 0, source: 0, action: null, timer: null };
  const snap = () => E.snapshots[state.index];
  const pad = n => String(n).padStart(2, '0');
  const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;
  const badge = r => `<span class="status-pill ${r.key}">${r.label}</span>`;
  let toastTimer;
  function toast(message) { $('toast').textContent = message; $('toast').classList.add('visible'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.remove('visible'), 4500); }
  function announce(message) { $('announcement').textContent = message; }

  function renderControls() {
    const s = snap();
    $('step-count').innerHTML = `${pad(state.index + 1)} <small>/ 12</small>`;
    $('story-title').textContent = s.title;
    $('story-range').value = state.index;
    $('story-range').style.setProperty('--progress', `${state.index / 11 * 100}%`);
    $('story-range').setAttribute('aria-valuetext', `Update ${state.index + 1}: ${s.title}, ${E.format(s.day)}`);
    $('play-button').innerHTML = icon(state.playing ? 'pause' : 'play') + `<span>${state.playing ? 'Pause story' : state.index >= E.alertIndex ? 'Replay story' : 'Play story'}</span>`;
    $('next-button').disabled = state.index === E.snapshots.length - 1;
    $('simulation-date').innerHTML = `${icon('clock')}Simulation date: ${pad(E.date(s.day).getUTCDate())} ${E.format(s.day, { month: 'short', timeZone: 'UTC' })} 2026`;
    $('simulation-state').innerHTML = `<span class="status-dot"></span>${state.playing ? 'Simulation running' : state.index === E.alertIndex ? 'Paused at risk detection' : state.index ? 'Simulation paused' : 'Ready to simulate'}`;
    $('simulation-state').classList.toggle('live-pulse', state.playing);
    document.querySelectorAll('.scenario-button').forEach(el => { const active = el.dataset.step === '0' ? state.index < 8 : el.dataset.step === '8' ? state.index === 8 : state.index >= 9; el.classList.toggle('selected', active); el.setAttribute('aria-pressed', active); });
  }

  function renderKpis(etaChanged) {
    const s = snap(), r = E.risk(s.eta, s.high), prior = E.snapshots[Math.max(0, state.index - 1)];
    const width = s.high - s.low;
    const range = s.low === s.high ? E.format(s.low) : E.date(s.low).getUTCMonth() === E.date(s.high).getUTCMonth() ? `${E.date(s.low).getUTCDate()}–${E.format(s.high)}` : `${E.format(s.low)}–${E.format(s.high)}`;
    const warning = state.index >= 9 ? '5' : state.index === 8 ? '6' : '—';
    $('kpi-grid').innerHTML = `
      <article class="kpi-card kpi-eta"><div class="kpi-top">${s.completed === 9 ? 'Confirmed arrival' : 'Dynamic ETA'}${icon('calendar')}</div><div class="kpi-value ${etaChanged ? 'eta-flash' : ''}">${E.date(s.eta).getUTCDate()} <small>${E.format(s.eta, { month: 'long', timeZone: 'UTC' })}</small></div><div class="kpi-note">${prior.eta !== s.eta ? `<s>${E.format(prior.eta)}</s> → <strong>Updated prediction</strong>` : `Market request: ${E.format(E.requested)}`}</div></article>
      <article class="kpi-card"><div class="kpi-top">Confidence range${icon('target')}</div><div class="kpi-value range-value ${range.length > 10 ? 'long-range' : ''}">${range}</div><div class="kpi-note">${s.completed === 9 ? 'Actual delivery confirmed' : width ? `Illustrative 80% interval · ${plural(width, 'day')} wide` : 'Final-day estimate · day-level precision'}</div></article>
      <article class="kpi-card kpi-risk ${r.key}"><div class="kpi-top">Delivery risk${icon('shield')}</div><div class="kpi-value">${badge(r)}</div><div class="kpi-note">${r.delay ? `${plural(r.delay, 'day')} ${s.completed === 9 ? 'late at delivery' : 'after the market request'}` : `${plural(r.headroom, 'day')} before the market request`}</div></article>
      <article class="kpi-card"><div class="kpi-top">Early visibility${icon('eye')}</div><div class="kpi-value">${warning}${warning !== '—' ? '<small>days</small>' : ''}</div><div class="kpi-note">${state.index >= 9 ? 'Risk flagged 24 Oct · request 29 Oct' : state.index === 8 ? 'Watch signal 23 Oct · request 29 Oct' : 'No exception predicted yet'}</div></article>`;
  }

  function renderJourney() {
    const s = snap(), r = E.risk(s.eta, s.high);
    $('milestones').innerHTML = E.stages.map((stage, i) => {
      const done = i < s.completed, current = i === s.stage && s.completed < 9;
      return `<button class="milestone ${done ? 'done' : ''} ${current ? `current ${r.key}` : ''}" data-milestone="${i}" aria-pressed="${state.inspected === i}" aria-label="${stage.name}: ${done ? 'completed' : current ? 'current stage' : 'upcoming'}. Inspect details."><span class="milestone-node">${done ? icon('check') : current ? icon(stage.icon) : pad(i + 1)}</span><span class="milestone-label">${stage.name}</span></button>`;
    }).join('');
    const positions = [[162,77],[162,77],[162,77],[142,58],[142,58],[371,188],[590,191],[590,191],[650,154]];
    ['shipment-marker','shipment-pulse'].forEach(id => { $(id).setAttribute('cx', positions[s.stage][0]); $(id).setAttribute('cy', positions[s.stage][1]); });
    $('map-stage').innerHTML = `${icon(E.stages[s.stage].icon)}<strong>${E.stages[s.stage].name}</strong><span>${s.completed === 9 ? 'Arrived' : `Milestone ${pad(s.stage + 1)} / 09`}</span>`;
    renderMilestoneDetail();
  }
  function renderMilestoneDetail() {
    const s = snap(), stage = E.stages[state.inspected];
    const done = state.inspected < s.completed;
    const status = done ? 'Completed' : state.inspected === s.stage ? 'Current stage' : 'Upcoming';
    $('milestone-detail').innerHTML = `${icon(stage.icon)}<div><strong>${stage.name} <span class="muted">/ ${stage.location}</span></strong><p>${stage.description}</p></div><span class="detail-status">${status}</span>`;
  }

  function renderChart() {
    const s = snap(), r = E.risk(s.eta, s.high), xs = i => 48 + i * 35.1, ys = d => 185 - (d - 18) * 10;
    const observed = E.snapshots.slice(0, state.index + 1), lastX = xs(state.index);
    let band;
    if (state.index === 0) band = `<rect x="42" y="${ys(s.high)}" width="14" height="${ys(s.low) - ys(s.high)}" rx="3" class="forecast-area"/>`;
    else {
      const upper = observed.map((p, i) => `${xs(i)},${ys(p.high)}`).join(' ');
      const lower = observed.map((p, i) => `${xs(i)},${ys(p.low)}`).reverse().join(' ');
      band = `<polygon points="${upper} ${lower}" class="forecast-area"/>`;
    }
    const line = observed.map((p, i) => `${i ? 'L' : 'M'}${xs(i)},${ys(p.eta)}`).join(' ');
    const grid = [20,25,29,33].map(d => `<line class="chart-grid" x1="40" x2="445" y1="${ys(d)}" y2="${ys(d)}"/><text class="axis-text" x="1" y="${ys(d) + 3}">${E.format(d)}</text>`).join('');
    const labelX = state.index > 8 ? lastX - 9 : lastX + 9, anchor = state.index > 8 ? 'end' : 'start';
    $('eta-chart').innerHTML = `<svg viewBox="0 0 460 235" role="img" aria-label="ETA history. Current prediction ${E.format(s.eta)}, with illustrative range ${E.format(s.low)} to ${E.format(s.high)}. Market request ${E.format(E.requested)}."><text x="1" y="13" class="axis-text">ARRIVAL DATE</text>${grid}${band}<line x1="40" x2="445" y1="${ys(29)}" y2="${ys(29)}" stroke="var(--amber)" stroke-width="1" stroke-dasharray="4 4" opacity=".7"/><text class="requested-label" text-anchor="end" x="444" y="${ys(29) - 7}">Request · 29 Oct</text><line x1="${lastX}" x2="${lastX}" y1="24" y2="192" stroke="var(--subtle)" stroke-width=".7" stroke-dasharray="2 4" opacity=".4"/><path d="${line}" class="forecast-line"/>${observed.map((p, i) => `<circle cx="${xs(i)}" cy="${ys(p.eta)}" r="${i === state.index ? 4.5 : 2.5}" fill="${i === state.index && r.key !== 'green' ? `var(--${r.key})` : 'var(--accent)'}" stroke="var(--surface)" stroke-width="1.5"/>`).join('')}<text class="date-label" x="${labelX}" y="${ys(s.eta) - 11}" text-anchor="${anchor}">${E.format(s.eta)}</text><line x1="40" x2="445" y1="194" y2="194" class="chart-grid"/><text class="axis-text" x="40" y="211">Manufacturing</text><text class="axis-text" x="223" y="211" text-anchor="middle">Sea freight</text><text class="axis-text" x="329" y="211" text-anchor="middle">QI Bulk</text><text class="axis-text" x="442" y="211" text-anchor="end">Arrival</text><text class="axis-text" x="40" y="230">MILESTONE UPDATES →</text><text class="axis-text" x="442" y="230" text-anchor="end">As of ${E.format(s.day)}</text></svg>`;
    $('window-size').textContent = s.high === s.low ? (s.completed === 9 ? 'Delivery confirmed' : 'Day-level estimate') : `${plural(s.high - s.low, 'day')} wide`;
    $('confidence-bar').style.width = `${Math.max(8, 100 - (s.high - s.low) * 9)}%`;
  }

  function renderInsight() {
    const s = snap(), r = E.risk(s.eta, s.high);
    $('risk-insight').className = `risk-insight ${r.key}`;
    const title = s.completed === 9 ? 'Arrived 2 days late. Predicted 7 days earlier.' : r.key === 'red' ? `Predicted delay: ${plural(r.delay, 'day')}` : r.key === 'amber' ? 'A longer QI hold. One day of headroom.' : `${plural(r.headroom, 'day')} of headroom. No exceptions predicted.`;
    const detail = r.key === 'red' ? s.day <= 29 ? `Risk detected on 24 Oct, five days before the 29 Oct market request. ${s.message}` : `Risk was flagged on 24 Oct, before the 29 Oct request was missed. ${s.message}` : s.message;
    $('risk-insight').innerHTML = `${icon(r.key === 'green' ? 'shield' : 'alert')}<div><h2>${title}</h2><p>${detail}</p></div><div class="insight-date"><strong>${E.format(s.eta)}</strong><span>${s.completed === 9 ? 'Confirmed arrival' : 'Predicted arrival'}</span></div>`;
  }

  function signalMarkup(extended) {
    const s = snap(), variance = s.duration - s.expected;
    const makeBars = (count, exception = false) => `<span class="signal-bar" aria-hidden="true">${Array.from({ length: 8 }, (_, i) => `<i class="${i < count ? `filled ${exception ? 'exception' : ''}` : ''}"></i>`).join('')}</span>`;
    const cards = [
      { title: 'Current Node Duration', icon: 'clock', n: s.duration, bars: makeBars(Math.min(s.duration,8), variance > 0), description: s.completed === 9 ? 'Delivery confirmed at the final milestone.' : `${E.stages[s.stage].name} · ${variance > 0 ? `${plural(variance, 'day')} above typical` : variance === 0 ? 'Within the typical duration' : 'Within the typical duration'}`, formula: 'Elapsed time = simulation time − stage entry time. Source events may arrive after the physical stage entry.' },
      { title: 'Expected Node Duration', icon: 'activity', n: s.expected, bars: makeBars(s.expected), description: `Typical historical time for ${E.stages[s.stage].name}.`, formula: 'A route-and-stage historical median would form the reference. The values shown here are mocked.' },
      { title: 'Remaining Network Lead Time', icon: 'globe', n: s.remaining, bars: makeBars(Math.max(0, 9 - s.completed)), description: `${s.completed} of 9 milestones complete · time to market.`, formula: 'Estimated remaining dwell and future-stage durations, including calendar effects. Here: predicted arrival − simulation date.' }
    ];
    return cards.map(c => `<article class="signal-card"><div class="signal-top">${icon(c.icon)}${c.title}</div><div class="signal-number"><strong>${c.n} <small>${c.n === 1 ? 'day' : 'days'}</small></strong>${c.bars}</div><p>${c.description}</p>${extended ? `<div class="signal-formula">${c.formula}</div>` : ''}</article>`).join('');
  }

  function renderDrivers() {
    const s = snap(), qi = s.drivers[0], holiday = s.drivers[1], later = state.index >= 8;
    $('driver-summary').innerHTML = `<div class="driver-rows"><div class="driver-row ${later ? 'negative' : ''}"><div><span>${later ? 'QI Bulk delay' : 'Expected network variation'}</span><strong>+${plural(qi, 'day')}</strong></div><div class="driver-bar"><i style="width:${qi / 7 * 100}%"></i></div><p class="driver-subtext">${later ? `Projected QI residence: ${qi + 2} days vs a 2-day reference.` : 'Normal planning variation in this early estimate.'}</p></div><div class="driver-row secondary-driver"><div><span>Market holiday impact</span><strong>+${plural(holiday, 'day')}</strong></div><div class="driver-bar"><i style="width:${holiday / 7 * 100}%"></i></div><p class="driver-subtext">${holiday ? 'Illustrative receiving-calendar impact at the market.' : 'No calendar exception identified in the current estimate.'}</p></div><div class="driver-total"><span>Total above normal lead time</span><strong>+${plural(qi + holiday, 'day')}</strong></div><p class="driver-reference">Normal lead-time reference <strong>${E.format(E.normalReference)}</strong> + ${plural(qi + holiday, 'day')} = <strong>${E.format(s.eta)}</strong> predicted arrival.</p></div>`;
  }

  function actionsAvailable() { return state.index === 8 || state.index === 9; }
  function renderActions() {
    const available = actionsAvailable();
    $('action-intro').textContent = available ? 'Compare a response against the unmitigated forecast. Impacts are illustrative.' : state.index > 9 ? 'Replay the risk moment to explore actions while there is still time to respond.' : 'Recovery options activate when the shipment reaches Watch or At Risk.';
    $('action-list').innerHTML = E.actions.map(a => `<button class="action-option ${state.action === a.id ? 'selected' : ''}" data-action="${a.id}" aria-pressed="${state.action === a.id}" ${!available ? 'disabled' : ''}>${icon(a.icon)}<span class="action-text"><strong>${a.name}</strong><small>${a.description}</small></span><span class="action-value"><b>${a.recover ? `Recover ${plural(a.recover, 'day')}` : 'No time recovery'}</b><span>${a.effort}</span></span></button>`).join('');
    renderActionPreview();
  }
  function renderActionPreview() {
    const p = state.action ? E.preview(snap(), state.action) : null;
    $('action-preview').classList.toggle('active', !!p);
    if (!p) { $('action-preview').innerHTML = `${icon('target')}<p class="preview-empty">${actionsAvailable() ? 'Select an action to preview its fulfilment date and delivery risk.' : 'Action previews show the potential recovery without changing the original ETA.'}</p>`; return; }
    $('action-preview').innerHTML = `<div class="preview-dates"><div class="old-date"><small>MODEL ETA</small>${E.format(snap().eta)}</div>${icon('arrow')}<div class="new-date"><small>FULFILMENT ESTIMATE</small>${E.format(p.eta)}</div></div><div class="preview-reason"><strong>${p.recovered ? `${plural(p.recovered, 'day')} of potential recovery` : 'No change to the arrival estimate'}</strong>${badge(p.risk)} <button data-clear-preview>Clear preview</button></div><p class="preview-assumption">${p.action.detail} Illustrative scenario only; no action is dispatched.</p>`;
  }

  function renderEvents() {
    $('event-count').textContent = `${state.index + 1} ${state.index ? 'events' : 'event'} received`;
    $('event-feed').innerHTML = E.snapshots.slice(Math.max(0, state.index - 2), state.index + 1).reverse().map(s => `<article class="event-item"><small>${E.format(s.day)} 2026 · ${s.index === state.index ? 'Latest update' : 'Milestone update'}</small><strong>${E.stages[s.stage].name}</strong><p>${s.event}</p></article>`).join('');
  }

  const sources = [
    { name: 'ECC records', icon: 'database', sub: 'Orders, movements & timestamps', description: 'Order and movement records provide the operating context. In production, actual business events must be distinguished from posting timestamps.', fields: ['order_id','movement_type','event_time','posting_time'] },
    { name: 'Document flow relationships', icon: 'link', sub: 'The relationships between transactions', description: 'Predecessor and successor relationships connect an order to deliveries and shipments, so records can be assembled into the same journey.', fields: ['predecessor_document','successor_document','relationship_type'] },
    { name: 'Delivery documents', icon: 'document', sub: 'Outbound, inbound & receiving events', description: 'Delivery records identify origin, destination, dispatch and receipt. Actual events contribute to the observed milestone sequence.', fields: ['delivery_id','ship_from','ship_to','actual_gi_date'] },
    { name: 'Batch information', icon: 'batch', sub: 'Production & quality-release context', description: 'A batch key ties medicine production, release, and quality status to the physical stock in each delivery.', fields: ['batch_id','manufacture_date','quality_status','release_time'] },
    { name: 'Historical shipment records', icon: 'clock', sub: 'Route & stage duration references', description: 'Completed historical journeys supply route-specific typical durations and a basis for training and validating ETA estimates.', fields: ['shipment_id','route','stage','entered_at','completed_at'] }
  ];
  function renderSources() {
    $('source-list').innerHTML = sources.map((s, i) => `<button class="source-option ${state.source === i ? 'selected' : ''}" data-source="${i}" aria-pressed="${state.source === i}">${icon(s.icon)}<span><strong>${s.name}</strong><small>${s.sub}</small></span><span class="source-arrow">${icon('chevron')}</span></button>`).join('');
    const source = sources[state.source];
    $('source-detail').innerHTML = `<strong>${source.name}</strong><p>${source.description}</p><div class="source-fields">${source.fields.map(f => `<code>${f}</code>`).join('')}</div>`;
  }
  function renderData() {
    const s = snap(), firstObserved = [2,4,6,8,9,11,20,21,31], source = ['ECC + batch','Batch information','Delivery documents','Document flow','Shipment records','Shipment records','Delivery documents','Batch information','Delivery documents'];
    $('history-table').innerHTML = E.stages.map((stage, i) => {
      const arrived = firstObserved[i] <= s.day && (i !== 8 || s.completed === 9);
      const done = i < s.completed;
      const status = done ? 'Complete' : i === s.stage ? (i === 8 ? 'Approaching' : 'Active') : 'Upcoming';
      return `<tr><td><span>${pad(i + 1)}</span>${stage.name}</td><td>${arrived ? E.format(firstObserved[i]) : '—'}</td><td>${source[i]}</td><td><span class="table-status ${done ? 'done' : i === s.stage ? 'current' : ''}">${status}</span></td></tr>`;
    }).join('');
    $('data-signals').innerHTML = signalMarkup(true);
    $('data-asof').textContent = `Simulation: ${E.format(s.day)} 2026`;
  }

  function showWhy() {
    const s = snap(), qi = s.drivers[0], holiday = s.drivers[1], total = qi + holiday, later = state.index >= 8;
    const y = n => 192 - n * 18;
    const bars = `<rect x="58" y="${y(0)-4}" width="90" height="4" rx="2" fill="var(--subtle)"/><rect x="192" y="${y(qi)}" width="90" height="${Math.max(3,qi*18)}" rx="3" fill="${later ? 'var(--red)' : 'var(--accent)'}"/><rect x="326" y="${y(total)}" width="90" height="${Math.max(3,holiday*18)}" rx="3" fill="var(--amber)"/><rect x="460" y="${y(total)}" width="90" height="${Math.max(3,total*18)}" rx="3" fill="var(--accent)"/>`;
    $('why-content').innerHTML = `<div class="why-summary"><h3>${E.format(s.eta)}</h3><p>${later ? 'The forecast combines a projected QI overrun with an illustrative market-calendar effect.' : 'The initial forecast includes one day of expected network variation. No adverse exception is currently predicted.'}</p></div><div class="waterfall"><svg viewBox="0 0 610 254" role="img" aria-label="Waterfall: normal arrival ${E.format(24)}, ${later ? 'QI delay' : 'network variation'} plus ${qi} days, market holiday plus ${holiday} days, predicted arrival ${E.format(s.eta)}.">${[0,2,4,6,8].map(n => `<line x1="37" x2="576" y1="${y(n)}" y2="${y(n)}" stroke="var(--line)"/><text x="13" y="${y(n)+3}" fill="var(--subtle)" font-size="9">${n}d</text>`).join('')}${bars}<path d="M148 ${y(0)}H192M282 ${y(qi)}H326M416 ${y(total)}H460" fill="none" stroke="var(--subtle)" stroke-dasharray="3 3"/><g font-size="12" font-weight="600" text-anchor="middle"><text x="103" y="${y(0)-14}" fill="var(--muted)">24 Oct</text><text x="237" y="${y(qi)-12}" fill="${later ? 'var(--red)' : 'var(--accent)'}">+${qi} days</text><text x="371" y="${y(total)-12}" fill="var(--amber)">+${holiday} days</text><text x="505" y="${y(total)-12}" fill="var(--accent)">${E.format(s.eta)}</text></g><g font-size="10" fill="var(--muted)" text-anchor="middle"><text x="103" y="218">Normal reference</text><text x="237" y="218">${later ? 'QI Bulk delay' : 'Network variation'}</text><text x="371" y="218">Market holiday</text><text x="505" y="218">Predicted ETA</text><text x="305" y="244" font-size="9">CUMULATIVE DAYS ABOVE NORMAL REMAINING LEAD TIME</text></g></svg></div><div class="driver-explain-list"><div><span class="index">01</span><div><strong>${later ? 'QI Bulk delay' : 'Network variation'}: +${plural(qi, 'day')}</strong><p>${later ? `Projected total QI residence is ${qi + 2} days, compared with a two-day historical reference. ${state.index === 9 ? 'Four days have elapsed as of 24 Oct; the forecast includes three further QI days before release on 27 Oct.' : ''}` : 'The early forecast includes a one-day operating variation relative to the normal lead-time reference.'}</p></div></div><div><span class="index">02</span><div><strong>Market holiday impact: +${plural(holiday, 'day')}</strong><p>${holiday ? 'The illustrative destination calendar limits receiving and adds time after quality release.' : 'No market-calendar delay is included at this point in the scenario.'}</p></div></div></div><p class="normal-reference"><strong>Total impact: +${plural(total, 'day')} above normal lead time.</strong><br>The 24 Oct reference is a conditional arrival with normal remaining stage durations; it is not the original 25 Oct forecast. ${E.format(24)} + ${plural(total, 'day')} = ${E.format(s.eta)}.</p>`;
    if (!$('why-dialog').open) $('why-dialog').showModal();
  }

  function render(etaChanged = false) {
    renderControls(); renderKpis(etaChanged); renderJourney(); renderChart(); renderInsight();
    $('signal-grid').innerHTML = signalMarkup(false);
    renderDrivers(); renderActions(); renderEvents(); renderData();
    if ($('why-dialog').open) showWhy();
  }
  function stopPlayback() {
    clearInterval(state.timer); state.timer = null; state.playing = false; renderControls();
  }
  function setSnapshot(index, manual = true) {
    if (manual) stopPlayback();
    const previous = snap().eta;
    state.index = Math.max(0, Math.min(E.snapshots.length - 1, Number(index) || 0));
    state.inspected = snap().stage; state.action = null;
    render(previous !== snap().eta);
    announce(`${snap().title}. Simulation date ${E.format(snap().day)}. Predicted arrival ${E.format(snap().eta)}. ${E.risk(snap().eta, snap().high).label}.`);
  }
  function play() {
    if (state.playing) { stopPlayback(); return; }
    if (state.index >= E.alertIndex) setSnapshot(0);
    state.playing = true; renderControls();
    state.timer = setInterval(() => {
      setSnapshot(state.index + 1, false);
      if (state.index >= E.alertIndex) { stopPlayback(); toast('Risk identified five days before the market request. Explore Why? and compare recovery actions.'); }
    }, 2800);
  }
  function syncMenu() {
    const mobile = window.innerWidth <= 800, open = $('sidebar').classList.contains('open');
    $('sidebar').inert = mobile && !open;
    $('menu-button').setAttribute('aria-expanded', mobile && open ? 'true' : 'false');
    $('menu-button').setAttribute('aria-label', `${mobile && open ? 'Close' : 'Open'} navigation`);
  }
  function closeMenu(restoreFocus = false) {
    const wasOpen = $('sidebar').classList.contains('open');
    $('sidebar').classList.remove('open'); syncMenu();
    if (restoreFocus && wasOpen) $('menu-button').focus();
  }
  function navigate() {
    const raw = location.hash.slice(1);
    if (raw === 'main') { $('main').focus({ preventScroll: true }); return; }
    const page = ['overview','data','brief'].includes(raw) ? raw : 'overview';
    const changed = state.page !== page;
    if (page !== 'overview') stopPlayback();
    state.page = page;
    document.querySelectorAll('.page').forEach(el => { const active = el.id === `page-${page}`; el.classList.toggle('active', active); el.hidden = !active; });
    document.querySelectorAll('.nav-link').forEach(el => { const active = el.dataset.page === page; el.classList.toggle('active', active); if (active) el.setAttribute('aria-current', 'page'); else el.removeAttribute('aria-current'); });
    $('breadcrumb-current').textContent = { overview: 'Control tower', data: 'Data foundation', brief: 'Executive brief' }[page];
    closeMenu();
    if (changed) { window.scrollTo(0,0); $('main').focus({ preventScroll: true }); }
  }

  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    const dark = theme === 'dark';
    $('theme-button').innerHTML = icon(dark ? 'sun' : 'moon');
    $('theme-button').setAttribute('aria-label', `Switch to ${dark ? 'light' : 'dark'} mode`);
    try { localStorage.setItem('meridian-theme', theme); } catch (_) { /* file:// and privacy modes may disallow storage */ }
  }
  let initialTheme = 'light';
  try { const stored = localStorage.getItem('meridian-theme'); if (stored === 'dark' || stored === 'light') initialTheme = stored; } catch (_) {}
  setTheme(initialTheme);
  $('theme-button').addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'light' ? 'dark' : 'light'));
  $('play-button').addEventListener('click', play);
  $('next-button').addEventListener('click', () => setSnapshot(state.index + 1));
  $('reset-button').addEventListener('click', () => { setSnapshot(0); toast('Scenario reset. The shipment is healthy again.'); });
  $('story-range').addEventListener('input', e => setSnapshot(e.target.value));
  document.querySelectorAll('[data-step]').forEach(el => el.addEventListener('click', () => setSnapshot(el.dataset.step)));
  $('milestones').addEventListener('click', e => { const button = e.target.closest('[data-milestone]'); if (!button) return; state.inspected = Number(button.dataset.milestone); $('milestones').querySelectorAll('button').forEach(el => el.setAttribute('aria-pressed', el === button)); renderMilestoneDetail(); });
  $('action-list').addEventListener('click', e => { const button = e.target.closest('[data-action]'); if (!button || !actionsAvailable()) return; state.action = button.dataset.action; renderActions(); $('action-list').querySelector(`[data-action="${state.action}"]`).focus({ preventScroll: true }); const p = E.preview(snap(), state.action); announce(`${p.action.name}. Fulfilment estimate ${E.format(p.eta)}. ${p.risk.label}. ${plural(p.recovered, 'day')} potential recovery.`); });
  $('action-preview').addEventListener('click', e => { if (e.target.closest('[data-clear-preview]')) { state.action = null; renderActions(); $('action-list').querySelector('button').focus({ preventScroll: true }); } });
  $('source-list').addEventListener('click', e => { const button = e.target.closest('[data-source]'); if (!button) return; state.source = Number(button.dataset.source); renderSources(); $('source-list').querySelector(`[data-source="${state.source}"]`).focus(); });
  $('why-button').addEventListener('click', () => { stopPlayback(); showWhy(); });
  $('close-dialog').addEventListener('click', () => $('why-dialog').close());
  $('why-dialog').addEventListener('click', e => { if (e.target !== $('why-dialog')) return; const b = $('why-dialog').getBoundingClientRect(); if (e.clientX < b.left || e.clientX > b.right || e.clientY < b.top || e.clientY > b.bottom) $('why-dialog').close(); });
  $('menu-button').addEventListener('click', () => { const open = $('sidebar').classList.toggle('open'); syncMenu(); if (open) $('sidebar').querySelector('.nav-link.active').focus(); });
  $('sidebar').addEventListener('click', e => { const link = e.target.closest('a'); if (!link || window.innerWidth > 800) return; closeMenu(); if (link.dataset.page === state.page) $('main').focus({ preventScroll: true }); });
  document.addEventListener('click', e => { if (window.innerWidth > 800 || e.target.closest('#sidebar') || e.target.closest('#menu-button')) return; closeMenu(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(true); });
  window.addEventListener('resize', syncMenu);
  $('replay-button').addEventListener('click', () => { location.hash = 'overview'; navigate(); setSnapshot(0); play(); });
  $('risk-jump-button').addEventListener('click', () => { location.hash = 'overview'; navigate(); setSnapshot(9); });
  $('print-button').addEventListener('click', () => window.print());
  window.addEventListener('hashchange', navigate);
  window.addEventListener('pagehide', stopPlayback);
  document.addEventListener('visibilitychange', () => { if (document.hidden && state.playing) stopPlayback(); });
  renderSources(); render(); navigate(); syncMenu();
})();
