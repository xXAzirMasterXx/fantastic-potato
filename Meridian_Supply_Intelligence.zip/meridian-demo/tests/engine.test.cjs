const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../src/engine.js');

test('the story visits nine stages, then confirms final delivery', () => {
  assert.equal(E.stages.length, 9);
  assert.deepEqual([...new Set(E.snapshots.map(s => s.stage))], [0,1,2,3,4,5,6,7,8]);
  assert.equal(E.snapshots.at(-1).completed, 9);
  for (let i = 1; i < E.snapshots.length; i++) {
    assert.ok(E.snapshots[i].day > E.snapshots[i-1].day);
    assert.ok(E.snapshots[i].completed >= E.snapshots[i-1].completed);
  }
});
test('initial, QI hold, and risk states demonstrate the requested ETA story', () => {
  const [healthy, watch, risk] = [E.snapshots[0], E.snapshots[8], E.snapshots[9]];
  assert.deepEqual([healthy.eta,watch.eta,risk.eta], [25,28,31]);
  assert.deepEqual([healthy,watch,risk].map(s => E.risk(s.eta,s.high).label), ['On Track','Watch','At Risk']);
  assert.equal(E.risk(risk.eta,risk.high).delay,2);
  assert.equal(E.requested - risk.day,5);
  assert.equal(risk.duration,4);
  assert.equal(risk.expected,2);
});
test('prediction ranges contain the ETA, narrow as evidence arrives, and attribution reconciles', () => {
  let width = Infinity;
  for (const s of E.snapshots) {
    assert.ok(s.low <= s.eta && s.eta <= s.high);
    assert.ok(s.high - s.low <= width);
    width = s.high - s.low;
    assert.equal(E.normalReference + s.drivers.reduce((a,b) => a+b,0), s.eta);
    assert.equal(s.remaining,Math.max(0,s.eta-s.day));
  }
  assert.deepEqual(E.snapshots[9].drivers, [5,2]);
});
test('risk rules cover early arrival, boundary dates, uncertainty, and missed commitments', () => {
  assert.equal(E.risk(25,27).key,'green');
  assert.equal(E.risk(27,29).key,'amber');
  assert.equal(E.risk(28,28).key,'amber');
  assert.equal(E.risk(29,29).key,'amber');
  assert.equal(E.risk(30,30).key,'red');
});
test('planner actions preview fulfilment without modifying the source forecast', () => {
  const s = E.snapshots[9];
  const expedite = E.preview(s, 'expedite');
  assert.equal(expedite.eta,28);
  assert.equal(expedite.recovered,3);
  assert.equal(expedite.risk.key,'amber'); // One day of buffer is still Watch by the stated rule.
  assert.equal(E.preview(s,'inventory').eta,29);
  assert.equal(E.preview(s,'production').eta,30);
  assert.equal(E.preview(s,'engage').eta,31);
  assert.equal(E.preview(s,'monitor').eta,31);
  assert.equal(s.eta,31);
  assert.equal(E.preview(s,'unknown'),null);
  assert.ok(E.preview(E.snapshots[10],'expedite').eta >= E.snapshots[10].day);
});
test('UTC date formatting handles the October to November boundary', () => {
  assert.equal(E.format(25),'25 Oct');
  assert.equal(E.format(32),'1 Nov');
});
test('the assembled application runs without externally loaded assets or build placeholders', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const html = fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
  assert.doesNotMatch(html,/\/\*__(STYLES|ENGINE|APP)__\*\//);
  assert.doesNotMatch(html,/<script\b[^>]*\bsrc\s*=/i);
  assert.doesNotMatch(html,/@import\b/i);
  assert.doesNotMatch(html,/\b(?:src|href)\s*=\s*["'](?:https?:)?\/\//i);
  assert.equal((html.match(/<script>/g)||[]).length,2);
  assert.match(html,/<meta name="viewport"/);
  assert.match(html,/<style>/);
});
