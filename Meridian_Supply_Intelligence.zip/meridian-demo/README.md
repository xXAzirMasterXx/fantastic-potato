# Meridian — Supply Intelligence

A self-contained, executive-style demonstration of predictive supply chain visibility. Follow a pharmaceutical shipment from Basel, via Rotterdam and the Singapore regional hub, to Manila.

## Open the demo

1. Extract the ZIP completely.
2. Double-click **index.html** and open it in a modern browser such as Edge, Chrome, Firefox, or Safari.
3. Select **Play story**.

The HTML file contains every stylesheet, icon, chart, data record, and script it needs. You can copy just `index.html` to another computer and run it without internet access. No backend, sign-in, package installation, API key, CDN, or external font is required. JavaScript must be enabled.

If your work computer restricts opening local HTML, use an approved local static server instead. From the extracted project folder:

```powershell
# Windows, if Python is already installed
py -m http.server 8000 --bind 127.0.0.1
```

```bash
# macOS / Linux, if Python is already installed
python3 -m http.server 8000 --bind 127.0.0.1
```

Then open **http://127.0.0.1:8000**. This is an optional file server only; there is no application backend. Stop it with Ctrl+C.

## A two-minute leadership walkthrough

1. **Start healthy.** The ETA is 25 October 2026, four days ahead of the market's 29 October request. All nine milestones are visible. Click a milestone to inspect its role without changing the simulation.
2. **Play the journey.** Twelve deterministic event snapshots move the shipment through Manufacturing, Release, Warehouse, Export, Port, Sea Freight, Import, QI Bulk, and Market Arrival. Each update refreshes the indicators and the chart. Playback pauses automatically at risk detection, after approximately 25 seconds.
3. **Watch the signal.** On 23 October, the QI Bulk hold moves the ETA from 25 to 28 October. The status becomes amber, with one day of headroom.
4. **Spot risk early.** On 24 October, the ETA becomes 31 October. A red warning shows a predicted two-day delay, detected five days before the requested arrival date.
5. **Ask why.** Click **Why?** to open a waterfall: normal remaining lead time implies 24 October; projected QI overrun adds five days; an illustrative market holiday adds two more, producing 31 October. The 24 October conditional reference is different from the early 25 October forecast, which included one day of normal network variation.
6. **Compare a response.** Select **Expedite freight** to compare the original 31 October model ETA with an illustrative 28 October fulfilment estimate. The three-day recovery is an assumption, not a guarantee. The status remains Watch because only one day of buffer remains. Other choices include alternate inventory, a replacement batch, stakeholder engagement, and monitoring. Every option shows its assumptions and potential impact. Previews never overwrite the original model forecast or send an action.
7. **Connect the data.** Open **Data foundation** to inspect the five input layers, their example fields, the joined milestone history, and the three live predictive features. Future milestones have no actual event dates. Observed timestamps can lag physical stage entry.
8. **Close with the value.** Open **Executive brief** for the tracking-versus-prediction comparison, scenario outcomes, and business benefits. **Print brief** opens the browser's print dialog; choose Save as PDF if desired. For a light printout, switch to light mode first.

Use **Next update** to continue past the alert and observe the unmitigated shipment's final arrival. Use **Healthy**, the reset icon, or **Replay story** to start again. The desktop slider can scrub through every snapshot. On small screens, swipe the milestone row to inspect later stages. The sidebar becomes a menu.

## Included features

- Animated shipment route and nine interactive milestones.
- Twelve event updates with play/pause, reset, next-update, slider, and scenario shortcuts.
- Dynamic ETA, illustrative 80% interval, risk status, and early-warning metrics.
- A prediction-history chart whose interval narrows as events become observed.
- Current Node Duration, Expected Node Duration, and Remaining Network Lead Time.
- Prominent green, amber, and red planner warnings.
- Explainability dialog with a contribution waterfall and detailed reasoning.
- Five recovery-action previews, showing both the original forecast and a possible fulfilment date.
- Data-source inspection, joined shipment history, and production-model methodology notes.
- Executive summary with a print layout.
- Responsive light and dark themes, keyboard access, accessible chart descriptions, and reduced-motion support.

Only the theme preference is stored in this browser, when local storage is available. Shipment state resets when the page reloads. No information leaves the app.

## Source structure

```text
index.html               Ready-to-run standalone application
src/template.html        Page structure and content
src/styles.css           Responsive themes and print styles
src/engine.js            Deterministic scenario, date/risk logic, action assumptions
src/app.js               Rendering and interactions
build.mjs                Dependency-free assembler
package.json             Optional development commands; no dependencies
tests/engine.test.cjs     Scenario and offline-package checks
README.md                This guide
VERIFICATION.md          Checks completed for this delivery
.gitignore               Excludes generated local development output
```

### Edit and rebuild (optional)

Editing the single `index.html` directly works without any build tool. If you prefer editing the separated files in `src/`, use an existing Node.js 18+ installation:

```bash
node build.mjs
node --test tests/engine.test.cjs
```

The build writes `index.html` and a matching `dist/index.html`. There is no `npm install` step and no network access is used. Rebuilding replaces manual edits to the generated HTML, so edit either the source or the generated file consistently.

The full extracted folder can be committed to a Git repository. Keep `index.html` tracked so a clone can run immediately without a development environment.

## Mock-data boundaries

This is a proof of concept, not a deployed or trained machine learning model. Dates, source records, holiday effects, duration references, forecasts, action impacts, and intervals are mocked. The illustrative 80% interval has not been calibrated or validated. A narrower interval illustrates reduced uncertainty; it does not establish measured accuracy. The map is a network schematic rather than a navigational map.

The simulated clock starts on 2 October 2026; it does not use your computer's current date. Dates are handled in UTC to avoid time-zone shifts.

Risk rules:

- **At Risk:** central predicted arrival is after 29 October.
- **Watch:** central predicted arrival is within one day of the request, or the upper illustrative interval reaches the request.
- **On Track:** neither condition applies.

Real recovery would depend on stock availability, capacity, costs, carrier schedules, quality release, and regulatory requirements. Quality inspection is never bypassed in the illustrated response. A production implementation would require ERP integration, a trained and validated model, calibrated intervals, and properly governed planner workflows.
